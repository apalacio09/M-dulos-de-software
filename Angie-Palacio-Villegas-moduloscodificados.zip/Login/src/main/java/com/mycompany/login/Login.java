/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.login;

/**
 *
 * @author angie
 */
public class Login {

    public static void main(String[] args) {
        fromlogin objetoLogin = new fromlogin();
        objetoLogin.setVisible(true);

        
    }
}

create database login;
use login;

create table Usuarios (
id int auto_increment primary key not null,
ingresoUsuario nvarchar(50),
ingresoContrasenia nvarchar(50)
);

select * from Usuarios;

insert into Usuarios(ingresoUsuario,ingresoContrasenia) values ('admin','contra2022');
insert into Usuarios(ingresoUsuario,ingresoContrasenia) values ('vendedor','vendedor2022');

select * from Usuarios where Usuarios.ingresoUsuario = 'admin' and Usuarios.ingresoContrasenia='contra2022';



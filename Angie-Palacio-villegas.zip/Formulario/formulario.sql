create database bdformulario;
use bdformulario;

create table Clientes(
id int not null auto_increment primary key,
NombreEmpresa nvarchar (50),
NombreCliente nvarchar (50),
Telefono nvarchar (20),
EstadodeCuenta nvarchar (50),
Asesor nvarchar (50)
);

/*Insertar*/
insert  into Clientes (NombreEmpresa,NombreCliente,Telefono,EstadodeCuenta,Asesor) values ('AsesoriaABC','Fran','3135144729','Activo','Jorge');
insert  into Clientes (NombreEmpresa,NombreCliente,Telefono,EstadodeCuenta,Asesor) values ('icono','Amelia','3135472526','Inactivo','Ximena');
insert  into Clientes (NombreEmpresa,NombreCliente,Telefono,EstadodeCuenta,Asesor) values ('Pañaleria','Sofia','3123456322','Activo','Jorge');

/*Mostrar*/
select * from Clientes;

/*Actualizar*/
update Clientes set Clientes.NombreEmpresa = 'interrapidisimo', Clientes.NombreCliente = 'Carlos', Clientes.Telefono = '3135144926', Clientes.EstadodeCuenta = 'Activo',Clientes.Asesor = 'Ximena' where Clientes.id=1;

/*Eliminar*/
delete from Clientes where Clientes.id=2;

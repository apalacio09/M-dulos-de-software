/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.formulario;

/**
 *
 * @author angie
 */
public class Inicio {
    
    public static void main(String[] args) {
        
        FormCuentas objetoformulario = new FormCuentas();
        objetoformulario.setVisible(true);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.formulario;


import com.mysql.cj.protocol.Resultset;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;


/**
 *
 * @author angie
 */
public class Clientes {
    
    int codigo;
    String nombreempresaclientes;
    String nombreclientes;
    String telefonoclientes;
    String estadodecuentasclientes;
    String asesorclientes;
    

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombreempresaclientes() {
        return nombreempresaclientes;
    }

    public void setNombreempresaclientes(String nombreempresaclientes) {
        this.nombreempresaclientes = nombreempresaclientes;
    }

    public String getNombreclientes() {
        return nombreclientes;
    }

    public void setNombreclientes(String nombreclientes) {
        this.nombreclientes = nombreclientes;
    }

    public String getTelefonoclientes() {
        return telefonoclientes;
    }

    public void setTelefonoclientes(String telefonoclientes) {
        this.telefonoclientes = telefonoclientes;
    }

    public String getEstadodecuentasclientes() {
        return estadodecuentasclientes;
    }

    public void setEstadodecuentasclientes(String estadodecuentasclientes) {
        this.estadodecuentasclientes = estadodecuentasclientes;
    }

    public String getAsesorclientes() {
        return asesorclientes;
    }

    public void setAsesorclientes(String asesorclientes) {
        this.asesorclientes = asesorclientes;
    }
    
    public void InsertarClientes(JTextField paramNombreEmpresa, JTextField paramNombreCliente, JTextField paramTelefono, JTextField paramEstadodeCuenta, JTextField paramAsesor){
    
        setEstadodecuentasclientes(paramNombreEmpresa.getText());
        setNombreclientes(paramNombreCliente.getText());
        setTelefonoclientes(paramTelefono.getText());
        setEstadodecuentasclientes(paramEstadodeCuenta.getText());
        setAsesorclientes(paramAsesor.getText());
        
        
        
        CConexion objetoConexion = new CConexion();
        
        String consulta ="insert  into Clientes (NombreEmpresa,NombreCliente,Telefono,EstadodeCuenta,Asesor) values ('?','?','?','?','?');";
        
        
        try {
            
            CallableStatement cs = objetoConexion.establececonexion().prepareCall(consulta);
            
            cs.setString(1, getNombreempresaclientes());
            cs.setString(2, getNombreclientes());
            cs.setString(3, getTelefonoclientes());
            cs.setString(4, getEstadodecuentasclientes());
            cs.setString(5, getAsesorclientes());
            
            
            JOptionPane.showMessageDialog(null,"Consulta test: "+cs.toString());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null,"Se inserto correctamente el cliente");
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null,"No se inserto correctamente el cliente,error"+e.toString());
            
        }
        
    }
    
    public void MostrarCLientes(JTable paramTotalClientes){
        
        CConexion objetoConexion = new CConexion();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla= new  TableRowSorter<TableModel>(modelo);
        paramTotalClientes.setRowSorter(OrdenarTabla);
        
        String sql="";
        
        modelo.addColumn("id");
        modelo.addColumn("NombreEmpresa");
        modelo.addColumn("NombreCliente");
        modelo.addColumn("Telefono");
        modelo.addColumn("EstadodeCuenta");
        modelo.addColumn("Asesor");
        
        
        paramTotalClientes.setModel(modelo);
        
        sql ="select * from Clientes;";
        
        String[] datos = new String[6];
        Statement st;
        
        try {
            
            st = objetoConexion.establececonexion().createStatement();
            
            ResultSet rs =st.executeQuery(sql);
            
            while(rs.next()){
                
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                
                modelo.addRow(datos);
            }
            
            paramTotalClientes.setModel(modelo);
            
            
                        
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null,"no se pudo mostrar los registros,error"+ e.toString());
            
        }
        
        
        
        
    }
    
    public void SeleccionarClientes(JTable paramListadodeClientes, JTextField paramid, JTextField paramNombreEmpresa, JTextField paramNombreCliente, JTextField paramTelefono ,JTextField paramEstadodeCuenta, JTextField paramAsesor){
        
        
        try {
            
            int fila = paramListadodeClientes.getSelectedRow();
            
            if (fila >=0) {
                
                paramid.setText(paramListadodeClientes.getValueAt(fila, 0).toString());
                paramNombreEmpresa.setText(paramListadodeClientes.getValueAt(fila, 1).toString());
                paramNombreCliente.setText(paramListadodeClientes.getValueAt(fila, 2).toString());
                paramTelefono.setText(paramListadodeClientes.getValueAt(fila, 3).toString());
                paramEstadodeCuenta.setText(paramListadodeClientes.getValueAt(fila, 4).toString());
                paramAsesor.setText(paramListadodeClientes.getValueAt(fila, 5).toString());
                                    
            }
            
            else{
                
                JOptionPane.showMessageDialog(null,"fila no seleccionada");
            }
                    
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null,"Error de seleccion,Error:"+e.toString());
            
        }
    }

public void ActualizarClientes(JTextField paramcodigo, JTextField paramNombreEmpresa, JTextField paramNombreCliente, JTextField paramTelefono, JTextField paramEstadodeCuenta, JTextField paramAsesor ){
    
    setCodigo(Integer.parseInt(paramcodigo.getText()));
    setNombreempresaclientes(paramNombreEmpresa.getText());
    setNombreclientes(paramNombreCliente.getText());
    setTelefonoclientes(paramTelefono.getText());
    setEstadodecuentasclientes(paramEstadodeCuenta.getText());
    setAsesorclientes(paramAsesor.getText());
    
    
    CConexion objetoConexion =new CConexion();
    
    String consulta ="update Clientes set Clientes.NombreEmpresa = '?', Clientes.NombreCliente = '?', Clientes.Telefono = '?', Clientes.EstadodeCuenta = '?',Clientes.Asesor = '?' where Clientes.id=?;";
    
    
    try {
    
        CallableStatement cs = objetoConexion.establececonexion().prepareCall(consulta);
        
        cs.setString(1, getNombreempresaclientes());
        cs.setString(2, getNombreclientes());
        cs.setString(3, getTelefonoclientes());
        cs.setString(4, getEstadodecuentasclientes());
        cs.setString(5, getAsesorclientes());
        cs.setInt(6, getCodigo());
                
        cs.execute();
        
        JOptionPane.showMessageDialog(null,"modificacion exitosa");
        
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null,"No se puede modificar"+e.toString());
        
        
    }
    
}

public void EliminarCliente(JTextField paramcodigo){
    
    setCodigo(Integer.parseInt(paramcodigo.getText()));
    
    CConexion objetoConexion = new CConexion();
    
    String consulta = "delete from Clientes where Clientes.id=?;";
    
    try {
        
        CallableStatement cs = objetoConexion.establececonexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        
        cs.execute();
        
        JOptionPane.showMessageDialog(null,"Se elimino correctamente");
        
        
    } catch (SQLException e) {
        
        JOptionPane.showMessageDialog(null,"no se pudo eliminar"+e.toString());
        
    }
}


   

}
